var fs = require('fs');
var locationData = fs.readFileSync('locationData.json');
var express = require('express');
var request = require('request');
var bodyParser = require('body-parser');
var app = express();
var branchFound = false;
app.enable('trust proxy');
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use(function(req,res,next){
	if(req.secure){
		next();
	}else{
		res.redirect('https://'+ req.headers.host+req.url);
	}
	
});

app.get('/', function(req, res) {
    res.send('Hotel Chatbot.');
});

// This code is called only when subscribing the webhook //
app.get('/webhook/', function (req, res) {
    if (req.query['hub.verify_token'] === 'brokerhotel') {
		console.log("broker get request called");
        res.send(req.query['hub.challenge']);
    }
    res.send('Error, wrong validation token');
})


// Incoming messages reach this end point //
app.post('/webhook/', function (req, res) {


    messaging_events = req.body.entry[0].messaging;

    for (i = 0; i < messaging_events.length; i++) {
        event = req.body.entry[0].messaging[i];
        sender = event.sender.id;
	
	   if (event.message && event.message.text) {
            text = event.message.text.toString();
			var messageData="";
			console.log("text message is ",text);
// Calling the FB Chat Server App. Change the address below to the url of your Weather app. Response is sent back to the user via the sendMessage function //
            
			/*
			request("https://fbchatserver.mybluemix.net/api/message?text=" + text, function (error, response, body) {
                sendMessage(sender, body);
            });
			*/
			request({
				url: 'https://universal-hotel.mybluemix.net/api/message',
				qs: {text: text},
				method: 'POST'
			}, function (error, response, body) {
				var body = JSON.parse(body);
				console.log("Body in text msg is:: "+body);
				
				sendMessage(sender, body);

	});
			
   }

} // end of for loop
	
    res.sendStatus(200);
});



// This function receives the response text and sends it back to the user //
function sendMessage(sender,text) {
		messageData = {
			text: text
		}
		
    request({
        url: 'https://graph.facebook.com/v2.6/me/messages',
        qs: {access_token: token},
        method: 'POST',
        json: {
            recipient: {id: sender},
            message: messageData,
        }
    }, function (error, response, body) {
        if (error) {
            console.log('Error sending message: ', error);
        } else if (response.body.error) {
            console.log('Error: ', response.body.error);
        }
    });
};

function empty(data){

  if(typeof(data) == 'number' || typeof(data) == 'boolean')
  { 
    return false; 
  }
  if(typeof(data) == 'undefined' || data === null)
  {
    return true; 
  }
  if(typeof(data.length) != 'undefined')
  {
    return data.length == 0;
  }
  var count = 0;
  for(var i in data)
  {
    if(data.hasOwnProperty(i))
    {
      count ++;
    }
  }
  return count == 0;
}
// bank of sherwood
var token = 
"EAAT8PI5WRhoBAMZAjtNxNHtZCbfuEiIKZB5Uq1OKk1XmcKePgHE2hyZCHgTiOjRjMzEP6ZAF0Pf5gHbmj0SbZBN6uFz8iWwcBh9ZA2uJWqdHSfnEoY7IdqJeH3ZCURuMRuMDOK0KWUcqSZBSDVVmlFAJYQ4Kmo9sHVKJJPKXfEgAMnwZDZD";

var host = (process.env.VCAP_APP_HOST || 'localhost');
var port = (process.env.VCAP_APP_PORT || 3000);
app.listen(port, host,function(){
 console.log("Hotel broker is running on ",port);
});