'use strict';

//var request = require('request');
var context_var = {};
var express = require( 'express' );  // app server
var bodyParser = require( 'body-parser' ); 
var watson = require( 'watson-developer-cloud' ); 
//var rp = require('request-promise');
 // parser for post requests

var app = express();

// Bootstrap application settings
app.use( express.static( './public' ) ); // load UI from public folder
app.use(bodyParser.json());
 //"password": "30QBOuQHX1EN",
 // "username": "8dc3fb23-df09-4ab4-9630-ccdc254e6ffc"
 
 //username: process.env.CONVERSATION_USERNAME || 'c54f3c7d-2993-4c43-bb17-1c5da8e5b5d6',
 // password: process.env.CONVERSATION_PASSWORD || 'yOifkFyrlaDa',
 //train
 

 var conversation = watson.conversation( {
  url: 'https://gateway.watsonplatform.net/conversation/api',
  username: process.env.CONVERSATION_USERNAME || 'dec34710-355f-4f19-b7ca-8b6351b12cd3',
  password: process.env.CONVERSATION_PASSWORD || 'XJ3YUHVhpWnB',
  version_date: '2017-05-10',
  version: 'v1'
} );

app.post('/api/message', function(req, res) {

	var text = req.query.text;
	var workspace = '5065592c-d966-462f-82de-22106408e6d3' || process.env.WORKSPACE_ID;
	var payload = {
		workspace_id: workspace,
		context: {},
		input: {text}
	};
  if ( req.body ) {
	console.log('inside req.body');
		//initDBConnection();
		payload.input = {text};
		console.log('Inside the req.body.input paylod is::  '+payload.input);
     	payload.context = context_var; // fetched context		
  }
  conversation.message( payload, function(err, data) {
    if ( err ) {
      return res.status( err.code || 500 ).json( err );
    }
	
    return res.json( processResponse( payload, data ) );
  } );
} );

app.get('/api/message', function(req, res) {
//02f2eb19-7d65-40fc-815e-7f285279ee81
 // alliance 26f92eeb-806e-4b00-b580-3385306a30b1
//22ad9af7-4ebc-4e1c-ad8d-eb3aada540c3 ( train) 
	var text = req.query.text;
	var workspace = '5fb002dd-dc52-4dea-a354-78b7fa9aa7e9' || process.env.WORKSPACE_ID;
	var payload = {
		workspace_id: workspace,
		context: {},
		input: {text}
	};
  if ( req.body ) {
	console.log('inside req.body');
	console.log('text is ',text);
		//initDBConnection();
		//payload.input = {text};
		console.log('Inside the req.body.input paylod is::  '+payload.input);
     	payload.context = context_var; // fetched context		
  }
  conversation.message( payload, function(err, data) {
    if ( err ) {
		console.log("Error occured in calling Conversation");
      return res.status( err.code || 500 ).json( err );
    }
	processResponse(payload, data, function(err, data) {
      return res.status( 200 ).json( data );
    });
    //return res.json( processResponse( payload, data ));
  } );
} );

function processResponse(input,response) {

context_var = response.context;
return response.output.text[0]
	
	
  }		
  //return response.output.text[0];


	 
function getDateTime() {

    var date = new Date();

    var hour = date.getHours();
    hour = (hour < 10 ? "0" : "") + hour;

    var min  = date.getMinutes();
    min = (min < 10 ? "0" : "") + min;

    var sec  = date.getSeconds();
    sec = (sec < 10 ? "0" : "") + sec;

    var year = date.getFullYear();

    var month = date.getMonth() + 1;
    month = (month < 10 ? "0" : "") + month;

    var day  = date.getDate();
    day = (day < 10 ? "0" : "") + day;

    return year + ":" + month + ":" + day + ":" + hour + ":" + min + ":" + sec;

}

/**
 * Updates the response text using the intent confidence
 * @param  {Object} input The request to the Conversation service
 * @param  {Object} response The response from the Conversation service
 * @return {Object}          The response with the updated message
 */


function empty(data){

  if(typeof(data) == 'number' || typeof(data) == 'boolean')
  { 
    return false; 
  }
  if(typeof(data) == 'undefined' || data === null)
  {
    return true; 
  }
  if(typeof(data.length) != 'undefined')
  {
    return data.length == 0;
  }
  var count = 0;
  for(var i in data)
  {
    if(data.hasOwnProperty(i))
    {
      count ++;
    }
  }
  return count == 0;
}

//module.exports = app;
var host = (process.env.VCAP_APP_HOST || 'localhost');
var port = (process.env.VCAP_APP_PORT || 3001);
app.listen(port, host);
